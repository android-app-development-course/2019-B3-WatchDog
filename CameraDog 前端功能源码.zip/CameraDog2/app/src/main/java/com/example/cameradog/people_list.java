package com.example.cameradog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class people_list extends Fragment {
    @Nullable
    private ViewPager viewPager;
    private RadioGroup radioGroup;

    private RadioButton rb_black;
    private RadioButton rb_white;

    private List<Fragment> pages;
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.people_list, container, false);
        super.onCreate((savedInstanceState));
        pages = new ArrayList<>();

        pages.add(new black_Fragment());
        pages.add(new white_Fragment());

        viewPager = view.findViewById(R.id.vp_display);
        radioGroup = view.findViewById(R.id.rg_navi);
        rb_black = view.findViewById(R.id.rb_black);
        rb_white = view.findViewById(R.id.rb_white);
        viewPager.setAdapter(new FragmentPagerAdapter(getFragmentManager()) {
            @Override
            public Fragment getItem(int i) {
                return pages.get(i);
            }
            @Override
            public int getCount() {
                return pages.size();
            }
        });
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }
            @Override
            public void onPageSelected(int i) {
                switch (i) {
                    case 0:
                        rb_black.setChecked(true);
                        break;
                    case 1:
                        rb_white.setChecked(true);
                        break;
                }
            }
            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });
        rb_black.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                viewPager.setCurrentItem(0, true);
            }
        });
        rb_white.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                viewPager.setCurrentItem(1, true);
            }
        });
        return view;
    }
}

