package com.example.cameradog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.*;

import static cn.bmob.v3.Bmob.getApplicationContext;

public class HomepageDialog extends Dialog {
    private EditText name;
    private EditText noted;
    private EditText ip;
    private Button btnOK;
    private Button btnCancel;

    String V_name;
    String V_noted;
    String V_ip;
    public HomepageDialog(Context context)
    {
        super(context);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage_dialog);
        name =(EditText) findViewById(R.id.et_name);        //name
        noted =(EditText) findViewById(R.id.et_noted);      //noted
        ip  =(EditText) findViewById(R.id.et_IP);           //ip
        btnOK=(Button) findViewById(R.id.yes);              //确认
        btnCancel=(Button)findViewById(R.id.no);            //取消

        btnOK.setOnClickListener(new View.OnClickListener(){        //确认按钮
            @Override
            public void onClick(View v)
            {   if (TextUtils.isEmpty(name.getText())||TextUtils.isEmpty(ip.getText())||TextUtils.isEmpty(noted.getText())) {
                Toast.makeText(getContext(), "输入不能为空!", Toast.LENGTH_SHORT).show();
                return;
            }
               V_name=name.getText().toString();
               V_noted=noted.getText().toString();
               V_ip=ip.getText().toString();
               insert(V_name,V_noted,V_ip,"dashuaibi","123");
               dismiss();
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener(){    //取消按钮
            @Override
            public void onClick(View v)
            {
                dismiss();
            }
        });
    }
    private void insert(String name,String noted,String IP,String username,String pass)
    {
        final Person p2 = new Person();
        p2.setUsername(username);
        p2.setPassword(pass);
        p2.setBName(name);
        p2.setNoted(noted);
        p2.setIP(IP);
        p2.save(new SaveListener<String>() {
            @Override
            public void done(String objectId, BmobException e) {
                if(e==null){
                    //添加成功
                    Toast.makeText(getApplicationContext(), "添加数据成功，返回objectId为："+p2.getObjectId(), Toast.LENGTH_SHORT).show();
                }else{
                    //添加失败
                    Toast.makeText(getApplicationContext(), "添加数据失败，返回objectId为："+p2.getObjectId(), Toast.LENGTH_SHORT).show();
                }
            }

        });
    }

    //逻辑：在dialog文件实现获取数据库数据功能，然后在dialog文件修改数据，再回传数据库修改数据
    //需要实现功能：获取数据，修改数据库数据功能
    //或者简单地增加数据

    //接着在homepage文件实现获取数据并且更新数据的功能。
    //也就是获取数据就可以了。
}

