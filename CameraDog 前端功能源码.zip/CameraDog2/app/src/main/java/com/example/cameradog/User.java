package com.example.cameradog;

import cn.bmob.v3.BmobObject;

public class User extends BmobObject {
    String username;
    String password;
    String sign;
    public void setUsername(String username){this.username=username;}
    public void setPassword(String password){this.password=password;}
    public void setSign(String sign){this.sign=sign;}
    public String getUsername(){return username;}
    public String getPassword(){return password;}
    public String getSign(){return  sign;}
}
