package com.example.cameradog;

import cn.bmob.v3.BmobObject;


public class Person extends BmobObject {
    String name;
    String noted;
    String IP;
    String password;
    String username;
    public String getUsername() {return username;}
    public String getPassword(){return password;}
    public String getBName(){return name;}
    public String getNoted(){return noted;}
    public String getIP(){return IP;}

    public void setUsername(String username){this.username=username;}
    public void setPassword(String password){this.password=password;}
    public void setBName(String name){this.name=name;}
    public void setNoted(String noted){this.noted=noted;}
    public void setIP(String IP){this.IP=IP;}



}
