package com.example.cameradog;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import cn.bmob.v3.Bmob;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private ImageView tabHome;
    private ImageView tabCom;
    private ImageView tabMy;

    private Fragment mHome;         //Fragment Home
    private Fragment mCom;       //Fragment Community
    private Fragment mMy;                 //Fragment My
    private FragmentManager myFM;
    private void findView()
    {
        tabHome = (ImageView) this.findViewById(R.id.homePage);
        tabCom = (ImageView) this.findViewById(R.id.community);
        tabMy = (ImageView) this.findViewById(R.id.my);
        tabHome.setOnClickListener(this);
        tabCom.setOnClickListener(this);
        tabMy.setOnClickListener(this);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Bmob.initialize(this, "e61058e2a4e7856dfa9ba3e47478beb5");
            //bmob数据库

        setContentView(R.layout.activity_main);
        findView();
        myFM = getSupportFragmentManager();
        tabHome.performClick();
    }
    public void onClick(View view)
    {
        FragmentTransaction myTransaction = myFM.beginTransaction();
        hideAllFragment(myTransaction);
        switch(view.getId()) {
            case R.id.homePage:
                if(mHome==null){
                    HomePage homePage=new HomePage();
                    myTransaction.add(R.id.fragmentLay,homePage);
                }else{
                    myTransaction.show(mHome);
                }
                break;
            case R.id.community:
                if(mCom==null){
                    people_list peopleList =new people_list();
                    myTransaction.add(R.id.fragmentLay,peopleList);
                }else{
                    myTransaction.show(mCom);
                }
                break;
            case R.id.my:
                if(mMy==null){
                    My my =new My();
                    myTransaction.add(R.id.fragmentLay,my);
                }else{
                    myTransaction.show(mMy);
                }
                break;
        }
        myTransaction.commit();
    }
    public void hideAllFragment(FragmentTransaction transaction){
        if(mHome!=null){
            transaction.hide(mHome);
        }
        if(mCom!=null){
            transaction.hide(mCom);
        }
        if(mMy!=null){
            transaction.hide(mMy);
        }
    }
    @Override
    public void onAttachFragment(Fragment fragment) {
        if (mHome == null && fragment instanceof HomePage)
            mHome=fragment;
        if (mCom == null && fragment instanceof people_list)
            mCom = fragment;
        if (mMy == null && fragment instanceof My)
            mMy = fragment;
    }

}
