package com.example.cameradog;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;
import cn.bmob.v3.listener.UpdateListener;

public class Login extends AppCompatActivity implements View.OnClickListener {
    private EditText etUsername;// 用户名
    private EditText etPassword;// 密码
    private Button btnLogin;    // 登录
    private Button exit;   //退出
    Intent intent;
    String username;
    String password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_in);
        initView();
        intent = this.getIntent();
        //登录成功则跳转回界面，显示其他按钮
        //登陆失败不跳转，只提示

        //其他地方：
        //刷新列表同时取回数据库中指定objectId的username用以查询其数据
        //应用包括：homepage界面，people list界面

    }

    private void initView() {
        etUsername = (EditText) findViewById(R.id.account);
        etPassword = (EditText) findViewById(R.id.password);
        btnLogin = (Button) findViewById(R.id.login);
        exit = (Button) findViewById(R.id.signup);
        btnLogin.setOnClickListener(this);
        exit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login: {              //登录
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString();

                if (TextUtils.isEmpty(username)) {
                    Toast.makeText(this, "请输入帐号", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(this, "请输入密码", Toast.LENGTH_SHORT).show();
                    return;
                }
                logcheck(username,password);
                intent.putExtra("use",username);
                intent.putExtra("load","1");
                break;
            }
            case R.id.signup: {          //注册
                username = etUsername.getText().toString().trim();
                password = etPassword.getText().toString();
                signup(username,password);
            }
        }
    }

    private void logcheck(final String user, final String pass) {
        BmobQuery<Person> categoryBmobQuery = new BmobQuery<>();
        categoryBmobQuery.addWhereEqualTo("username", user);
        categoryBmobQuery.addWhereEqualTo("password", pass);
        categoryBmobQuery.addWhereEqualTo("sign","0");
        categoryBmobQuery.findObjects(new FindListener<Person>() {
            @Override
            public void done(List<Person> object, BmobException e) {
                if (e == null) {
                        change(user,pass);
                } else {
                    Toast.makeText(getApplicationContext(), "帐号或密码错误", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void change(String usern,String pass) {
        User p2 = new User();
        p2.setUsername(usern);
        p2.setPassword(pass);
        p2.update("215649cc00", new UpdateListener() {  //负责登录的数据库行
            @Override
            public void done(BmobException e) {
                if (e == null) {
                    Toast.makeText(getApplicationContext(), "登录成功", Toast.LENGTH_SHORT).show();
                    setResult(Activity.RESULT_OK, intent);
                    finish();
                }
                else {
                    Toast.makeText(getApplicationContext(), "登录失败", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }
    public void signup(String username,String pass){
            final User p2 = new User();
            p2.setUsername(username);
            p2.setPassword(pass);
            p2.setSign("0");//已注册帐号标识为0
            p2.save(new SaveListener<String>() {
                @Override
                public void done(String objectId, BmobException e) {
                    if(e==null){
                        //添加成功
                        Toast.makeText(getApplicationContext(), "注册成功", Toast.LENGTH_SHORT).show();
                    }else{
                        //添加失败
                        Toast.makeText(getApplicationContext(), "注册失败", Toast.LENGTH_SHORT).show();
                    }
                }

            });
        }
}