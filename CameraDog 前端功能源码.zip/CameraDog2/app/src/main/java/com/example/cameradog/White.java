package com.example.cameradog;

import cn.bmob.v3.BmobObject;

public class White extends BmobObject {
    String name;
}
