package com.example.cameradog;


public class Video {

    private String name;
    private int imageId;
    private String noted;
    private String ip;

    public Video(String name,int imageId,String noted,String ip){
        this.name=name;
        this.imageId=imageId;
        this.noted=noted;
        this.ip=ip;
    }
    public String getName(){
        return name;
    }
    public int getimageId(){
        return imageId;
    }
    public String getNoted(){
        return noted;
    }
    public String getIp(){return ip;}
}
