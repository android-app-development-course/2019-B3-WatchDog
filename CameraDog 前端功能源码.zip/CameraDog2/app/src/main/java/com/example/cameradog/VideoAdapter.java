package com.example.cameradog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class VideoAdapter extends ArrayAdapter<Video> {
        private int resourceId;
        public VideoAdapter(Context context, int textViewResourceId, List<Video> objects){
            super(context,textViewResourceId,objects);
            resourceId = textViewResourceId;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){
            //根据position获取待显示的video实例
            Video video = getItem(position);
            //获取子视图控件实例
            View view = LayoutInflater.from(getContext()).inflate(resourceId,parent,false);
            ImageView videoImage = (ImageView) view.findViewById(R.id.video_item_img);
            TextView videoName = (TextView) view.findViewById(R.id.video_item_name);
            TextView videoNote = (TextView) view.findViewById(R.id.video_item_noted);
            TextView videoIP = (TextView) view.findViewById(R.id.video_item_IP);
            //将video实例内的名和图片和备注赋值给子视图控件实例
            videoImage.setImageResource(video.getimageId());
            videoName.setText("用户名："+video.getName());
            videoNote.setText("备注："+video.getNoted());
            videoIP.setText("IP："+video.getIp());
            return view;
        }
}
