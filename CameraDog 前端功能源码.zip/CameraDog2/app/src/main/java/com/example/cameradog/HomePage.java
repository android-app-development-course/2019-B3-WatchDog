package com.example.cameradog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;

import static cn.bmob.v3.Bmob.getApplicationContext;

public class HomePage extends Fragment {
    private List<Video> videoList=new ArrayList<Video>();

    VideoAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home, container, false);
        adapter= new VideoAdapter(getActivity(), R.layout.video_item, videoList);
        ListView listview=view.findViewById(R.id.List);
        listview.setAdapter(adapter);
        //控件item点击事件
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Video video = videoList.get(i);
                Toast.makeText(getActivity(),video.getName(),Toast.LENGTH_LONG).show();
            }
        });

        init(view);//标题栏的点击按钮事件
        return view;
    }


    private void init(View view) //标题栏的点击按钮事件
    {
        TitlebarView titlebarView = (TitlebarView)view.findViewById(R.id.titleHome);
        titlebarView.setOnViewClick(new TitlebarView.onViewClick() {
            @Override
            public void leftClick() {       //可以实现刷新功能;
            equal();
            }
            @Override
            public void rightClick() {
                HomepageDialog dialog=new HomepageDialog(getActivity());
                dialog.show();
            }
        });
    }

   private void equal() {
       BmobQuery<Person> categoryBmobQuery = new BmobQuery<>();
       categoryBmobQuery.addWhereEqualTo("username", "dashuaibi");
       categoryBmobQuery.findObjects(new FindListener<Person>() {
           @Override
           public void done(List<Person> object, BmobException e) {
               if (e == null) {
                   List<Video> v1=new ArrayList<>();
                   for(int i=0;i<object.size();i++)
                   {
                       Video item =new Video(object.get(i).getBName(),R.drawable.timg,object.get(i).getNoted(),object.get(i).getIP());
                       v1.add(item);
                   }
                   adapter.clear();
                   adapter.addAll(v1);
                   Toast.makeText(getApplicationContext(), "查询成功：" + object.size(),Toast.LENGTH_SHORT).show();
               } else {
                   Toast.makeText(getApplicationContext(), "查询失败：" + object.size(),Toast.LENGTH_SHORT).show();
               }
           }
       });
   }
}