package com.example.cameradog;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class My extends Fragment {

   @Nullable

   private Button myBtn_one;
    private Button myBtn_two;
    private Button myBtn_three;
    private ImageView head;
    private AlertDialog dialog;
    private String name;
    private String pwd;
    private TextView T_name;
    private TextView T_val;
    public String loadsign="0";     //回传信息判断是否登录成功
    public String use;                 //回传用户名
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.my, container, false);
        myBtn_one = (Button) view.findViewById(R.id.btn_changepw);
        myBtn_two = (Button) view.findViewById(R.id.btn_notice);
        myBtn_three = (Button) view.findViewById(R.id.btn_signout);
        head=(ImageView) view.findViewById(R.id.h_head);        //头像点击
        T_name=(TextView)view.findViewById(R.id.user_name);
        T_val=(TextView)view.findViewById(R.id.user_val);

        myBtn_one.setVisibility(view.INVISIBLE);//按钮不可见
        myBtn_two.setVisibility(view.INVISIBLE);//不可见
        myBtn_three.setVisibility(view.INVISIBLE);//

        myBtn_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                customDialog();
            }
        });
        myBtn_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tipDialog();
            }
        });
        myBtn_three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tipDialog1();
            }
        });
        head.setOnClickListener(new View.OnClickListener() {        //头像
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),Login.class);
                startActivityForResult(intent,0);
            }
        });
        T_val.setOnClickListener(new View.OnClickListener() {
            //刷新

            @Override
            public void onClick(View view) {
                myBtn_one.setVisibility(getView().VISIBLE);//按钮可见
                myBtn_two.setVisibility(getView().VISIBLE);//可见
                myBtn_three.setVisibility(getView().VISIBLE);//
                T_name.setText(use);
                T_val.setText("欢迎您，爱你哦");
                if(loadsign=="0")
                {
                    myBtn_one.setVisibility(getView().INVISIBLE);//按钮不可见
                    myBtn_two.setVisibility(getView().INVISIBLE);//不可见
                    myBtn_three.setVisibility(getView().INVISIBLE);//
                    T_name.setText("未登录");
                    T_val.setText("请点击头像登录(点我刷新)");
                }
            }
        });
        return view;
    }
    /**
     * 修改密码
     */
    public void customDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        final AlertDialog dialog = builder.create();
        View dialogView = View.inflate(getContext(), R.layout.activity_custom, null);
        dialog.setView(dialogView);
        dialog.show();

        final EditText et_name = dialogView.findViewById(R.id.et_name);
        final EditText et_pwd = dialogView.findViewById(R.id.et_pwd);
        final Button btn_login = dialogView.findViewById(R.id.btn_login);
        final Button btn_cancel = dialogView.findViewById(R.id.btn_cancel);

        btn_login.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View view) {
                name = et_name.getText().toString();
                pwd = et_pwd.getText().toString();
                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(pwd)) {
                    Toast.makeText(getContext(), "密码不能为空!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(getContext(), "新密码：" + name + "\n" + "新密码2：" + pwd, Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }

        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }
    /**
     * 新消息
     */
    /**
     * 提示对话框
     */
    public void tipDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("提示：");
        builder.setMessage("您暂无新消息");
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setCancelable(true);            //点击对话框以外的区域是否让对话框消失

        //设置正面按钮
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {

            @Override

            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getContext() ,"您点击了确定", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }

        });
        AlertDialog dialog = builder.create();
        dialog.show();                              //显示对话框
    }
    /**
     * 提示对话框
     */
    public void tipDialog1() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("提示：");
        builder.setMessage("您确定要退出登陆吗");
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setCancelable(true);            //点击对话框以外的区域是否让对话框消失
        //设置正面按钮
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {

            @Override

            public void onClick(DialogInterface dialog, int which) {
                loadsign="0";
                Toast.makeText(getContext(), "您已退出登陆", Toast.LENGTH_SHORT).show();
                myBtn_one.setVisibility(getView().INVISIBLE);//按钮不可见
                myBtn_two.setVisibility(getView().INVISIBLE);//不可见
                myBtn_three.setVisibility(getView().INVISIBLE);//
                T_name.setText("未登录");
                T_val.setText("请点击头像登录（点我刷新）");
                dialog.dismiss();
            }

        });
        //设置反面按钮
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getContext(), "取消操作", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }

        });
        AlertDialog dialog = builder.create();      //创建AlertDialog对象
        dialog.show();                              //显示对话框
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode == Activity.RESULT_OK) {
            use=data.getStringExtra("use");
            loadsign=data.getStringExtra("load");
        }
    }
}


